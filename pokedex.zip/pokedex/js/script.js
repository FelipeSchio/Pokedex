const pokemonName = document.querySelector('.pokemon__name');
const pokemonNumber = document.querySelector('.pokemon__number');
const pokemonImage = document.querySelector('.pokemon__image');
const hitPoints = document.querySelector('.hitpoints');
const ataque = document.querySelector('.ataque');
const defesa = document.querySelector('.defesa');
const ataqueEspecial = document.querySelector('.ataqueespecial');
const defesaEspecial = document.querySelector('.defesaespecial');
const velocidade = document.querySelector('.velocidade');

const form = document.querySelector('.form');
const input = document.querySelector('.input__search');

const buttonPrev = document.querySelector('.btn-prev');
const buttonNext = document.querySelector('.btn-next');

const buttonShiny = document.querySelector('.btn-shiny');
const buttonGen1 = document.querySelector('.btn-gen1');
const buttonGen2 = document.querySelector('.btn-gen2');
const buttonGen3 = document.querySelector('.btn-gen3');
const buttonGen4 = document.querySelector('.btn-gen4');
const buttonGen5 = document.querySelector('.btn-gen5');
const buttonGen6 = document.querySelector('.btn-gen6');
const buttonGen7 = document.querySelector('.btn-gen7');
const buttonGen8 = document.querySelector('.btn-gen8');

let searchPokemon = 1; // Bulbasaur
let shiny = 0, gen = 0;
let imagemP = '';

const fetchPokemon = async (pokemon) => {
    const APIResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon}`);
    
    if (APIResponse.status == 200) {
        const data = await APIResponse.json();
        return data;
    }

}

const renderPokemon = async (pokemon) => {

    pokemonName.innerHTML = 'Carregando...';
    pokemonNumber.innerHTML = '';
    buttonShiny.disabled = false;
    buttonPrev.disabled = false;
    buttonNext.disabled = false;
    buttonGen1.innerHTML = 'Gen 1';
    buttonGen2.innerHTML = 'Gen 2';
    buttonGen3.innerHTML = 'Gen 3';
    buttonGen4.innerHTML = 'Gen 4';
    buttonGen5.innerHTML = 'Gen 5';
    buttonGen6.innerHTML = 'Gen 6';
    buttonGen7.innerHTML = 'Gen 7';
    buttonGen8.innerHTML = 'Gen 8';

    const data = await fetchPokemon(pokemon);
    
    buttonShiny.disabled = true;
    buttonShiny.innerHTML = 'Versão Shiny';
    // `buttonGen${gen}`.innerHTML = `Gen ${gen}`;
    
    if (data) {
        if (gen == 1) {
            imagemP = data['sprites']['versions']['generation-i']['red-blue']['front_transparent'];
            buttonGen1.innerHTML = 'Versão Padrão';
        } if (gen == 2) {
            imagemP = data['sprites']['versions']['generation-ii']['gold']['front_transparent'];
            buttonGen2.innerHTML = 'Versão Padrão';
        } if (gen == 3) {
            imagemP = data['sprites']['versions']['generation-iii']['emerald']['front_default'];
            buttonGen3.innerHTML = 'Versão Padrão';
        } if (gen == 4) {
            imagemP = data['sprites']['versions']['generation-iv']['diamond-pearl']['front_default'];
            buttonGen4.innerHTML = 'Versão Padrão';
        } if (gen == 5) {
            imagemP = data['sprites']['versions']['generation-v']['black-white']['animated']['front_default'];
            buttonGen5.innerHTML = 'Versão Padrão';
        } if (gen == 6) {
            imagemP = data['sprites']['versions']['generation-vi']['x-y']['front_default'];
            buttonGen6.innerHTML = 'Versão Padrão';
        } if (gen == 7) {
            imagemP = data['sprites']['versions']['generation-vii']['ultra-sun-ultra-moon']['front_default'];
            buttonGen7.innerHTML = 'Versão Padrão';
        } if (gen == 8) {
            imagemP = data['sprites']['versions']['generation-viii']['icons']['front_default'];
            buttonGen8.innerHTML = 'Versão Padrão';
        } if (gen == 0) {
            buttonShiny.disabled = false;
            if (shiny == 1) {
                imagemP = data['sprites']['front_shiny'];
                buttonShiny.innerHTML = 'Versão Normal';
            } else {
                imagemP = data['sprites']['front_default'];
            }
        }

        pokemonName.innerHTML = data.name;
        pokemonNumber.innerHTML = data.id;
        hitPoints.innerHTML = 'HP: ' + data['stats']['0']['base_stat'];
        ataque.innerHTML = 'AT: ' + data['stats']['1']['base_stat'];
        defesa.innerHTML = 'DF: ' + data['stats']['2']['base_stat'];
        ataqueEspecial.innerHTML = 'AE: ' + data['stats']['3']['base_stat'];
        defesaEspecial.innerHTML = 'DE: ' + data['stats']['4']['base_stat'];
        velocidade.innerHTML = 'VE: ' + data['stats']['5']['base_stat'];
        pokemonImage.src = imagemP;
        searchPokemon = data.id;
    } else {
        pokemonName.innerHTML = 'MissingNo.';
        pokemonNumber.innerHTML = '???';
        pokemonImage.src = 'images/Missingno.webp';
        buttonShiny.disabled = true;
        buttonPrev.disabled = true;
        buttonNext.disabled = true;
    }
    input.value = '';
}

form.addEventListener('submit', (event) =>{
    event.preventDefault();
    renderPokemon(input.value.toLowerCase());
});

buttonPrev.addEventListener('click', () =>{
    if (searchPokemon > 1) {
        searchPokemon -= 1;
        renderPokemon(searchPokemon);
    }
});

buttonNext.addEventListener('click', () =>{
    if (searchPokemon < 905) {
        searchPokemon += 1;
        renderPokemon(searchPokemon);
    }
});

buttonShiny.addEventListener('click', () =>{
    if (shiny == 0) {
        shiny = 1;
    } else {
        shiny = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen1.addEventListener('click', () =>{  
    if (gen != 1) {
        gen = 1;
        shiny = 0;
    } else {
        buttonGen1.innerHTML = 'Gen 1';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen2.addEventListener('click', () =>{  
    if (gen != 2) {
        gen = 2;
        shiny = 0;
    } else {
        buttonGen2.innerHTML = 'Gen 2';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen3.addEventListener('click', () =>{  
    if (gen != 3) {
        gen = 3;
        shiny = 0;
    } else {
        buttonGen3.innerHTML = 'Gen 3';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen4.addEventListener('click', () =>{  
    if (gen != 4) {
        gen = 4;
        shiny = 0;
    } else {
        buttonGen4.innerHTML = 'Gen 4';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen5.addEventListener('click', () =>{  
    if (gen != 5) {
        gen = 5;
        shiny = 0;
    } else {
        buttonGen5.innerHTML = 'Gen 5';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen6.addEventListener('click', () =>{  
    if (gen != 6) {
        gen = 6;
        shiny = 0;
    } else {
        buttonGen6.innerHTML = 'Gen 6';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen7.addEventListener('click', () =>{  
    if (gen != 7) {
        gen = 7;
        shiny = 0;
    } else {
        buttonGen7.innerHTML = 'Gen 7';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

buttonGen8.addEventListener('click', () =>{  
    if (gen != 8) {
        gen = 8;
        shiny = 0;
    } else {
        buttonGen8.innerHTML = 'Gen 8';
        gen = 0;
    }
    renderPokemon(searchPokemon);
});

renderPokemon(searchPokemon);